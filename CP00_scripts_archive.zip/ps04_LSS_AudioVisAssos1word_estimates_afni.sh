#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/mesocentre/data/agora/CP00'  # the project Main folder'
ddir="$mdir/AudioVisAsso/derivatives"    # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/afni"                        # AFNI output folder

# processing parameters
subj='sub-pilot2rc'                       # subject ID (should be a list)
task='task-AudioVisAssos1word'            # task name
deno='NR50'                               # denoising token
oglm="${subj}_${task}_GLM.wPSC.w${deno}"  # scaled model token
wdir="$adir/$subj/$task"                  # the Working folder
rdir="$adir/$subj/individual_ROIs"        # individual ROIs folder
vdir="$ddir/multivariate/$subj"           # multivariate folder

# create subject folder
if [ ! -d $vdir ];then
  mkdir -p $vdir/betas_afni
  mkdir -p $vdir/masks
fi

## prepare trial-wise estimates for multivariate analyses
#declare -a cons=("WA" "WV" "PA" "PV")
#i=1
#for icon in ${cons[@]};do
#  cprefix=`printf "con%d" $i`
#  ConvertAFNItoNIFTI $wdir/$oglm/trial-wise_estimates/LSS.stats.${subj}_${task}_${cprefix}_${icon}+tlrc $vdir/betas_afni ${cprefix}_trl
#  let i+=1
#done

## prepare trial-wise estimates of words and pseudowords separately for RSA
#mkdir -p $vdir/words/betas_afni   # words
#mkdir -p $vdir/pwords/betas_afni  # pseudowords
#cp -r $vdir/betas_afni/con*_W*.nii $vdir/words/betas_afni
#cp -r $vdir/betas_afni/con*_P*.nii $vdir/pwords/betas_afni

# prepare trial-wise estimates for MVPA
echo -e "Prepare LSS estimates of subject: $subj for MVPA......"
3dbucket -fbuc -aglueto $vdir/betas_afni/${subj}_LSS.nii.gz $vdir/betas_afni/con*.nii
3dTcat -prefix $vdir/betas_afni/${subj}_LSS_nilearn.nii.gz $vdir/betas_afni/${subj}_LSS.nii.gz
echo -e "The data preparation for MVPA for subject: $subj is done!"

# prepare ROI-masks
