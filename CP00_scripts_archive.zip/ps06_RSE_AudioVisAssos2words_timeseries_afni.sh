#!/bin/bash

## ---------------------------
## [script name] ps06_RSE_AudioVisAssos2words_timeseries_afni.sh 
##
## SCRIPT to ...
##
## By Shuai Wang, [date]
##
## ---------------------------
## Notes:
##   
##
## ---------------------------

## clean up
## ---------------------------

## set environment (packages, functions, working path etc.)
# setup path
mdir='/data/mesocentre/data/agora/CP00/AudioVisAsso'  # the project Main folder @totti
#mdir='/CP00/AudioVisAsso'  # the project Main folder @mesocentre 
adir="$mdir/derivatives/afni"                         # AFNI output folder
## ---------------------------

## individual processing parameters
subj='sub-pilot2rc'                                  # subject ID (should be a list)
task='task-AudioVisAssos2words'                      # task name
wdir="$adir/$subj/$task"                             # the Working folder
rdir="$adir/$subj/individual_ROIs"                   # the individual ROIs folder
rfile="$rdir/Consensus_ROIs_Labels.txt"  # ROIs list
readarray -t rois < $rfile                           # all ROIs
nrun=3                                               # number of runs
## ---------------------------

## extract PSC time-series for each ROI
gdir="$wdir/${subj}_${task}_GLM.wPSC.wNR50"  # PSC folder
fdir="$gdir/ROIana"
if [ ! -d $fdir ];then mkdir -p $fdir;fi
echo -e "Extracting time-series for all ROIs ......"
for irun in $(seq 1 $nrun);do
  frun=`printf "r%02d" $irun`
  bold="pb02.${subj}_${task}.${frun}.scale+tlrc"  # scaled PSC data
  # individual ROIs
  for iroi in ${rois[@]};do
    froi="ROI_${iroi}_${subj}_${task}.${frun}.scale.1D"
    3dmaskave -q -mask $rdir/${iroi}.nii $gdir/$bold > $fdir/$froi
  done
done
## ---------------------------

## extract FIR time course for each condition for each ROI
tdir="$wdir/${subj}_${task}_GLM.wPSC.wTENT.wNR50"  # TENT folder
if [ -d $tdir ];then
  cons=("SISMa" "SISMv" "SIDMa" "SIDMv" "DISMa" "DISMv" "DIDMa" "DIDMv" "catch")
  fdir="$tdir/ROIana"
  if [ ! -d $fdir ];then mkdir -p $fdir;fi
  echo -e "Extracting FIR time course for all ROIs ......"
  for icon in ${cons[@]};do
    firt="TENT_IRF_${icon}.${subj}_${task}+tlrc"
    # individual ROIs
    for iroi in ${rois[@]};do
     froi="ROI_${iroi}_${subj}_${task}.${icon}.IRF.1D"
     3dmaskave -q -mask $rdir/${iroi}.nii $tdir/$firt > $fdir/$froi
    done   
  done
else
  echo -e "There is no FIR model. Skip."
fi
## ---------------------------

echo -e "Finish extracting data for ROI-based analysis!"
