#!/bin/bash

#SBATCH -J afni
#SBATCH -p skylake
#SBATCH --nodes=1
#SBATCH -A a187
#SBATCH -t 6:00:00
#SBATCH --cpus-per-task=16
#SBATCH --mem=128gb
#SBATCH -o ./skylake_log/ps06_RSE_afni_%j.out
#SBATCH -e ./skylake_log/ps06_RSE_afni_%j.err
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ws1011001@gmail.com
#SBATCH --mail-type=BEGIN,END

# setup path
idir='/scratch/swang/simages'  # singularity images directory
mdir='/scratch/swang/agora/CP00'     # the project main directory
scripts='/CP00/scripts'        # scripts folder in Sy

# processing log
#echo -e 'Running ps02_GLM.AudioVisAssos2words.wPSC.wNR50_afni.sh with singularity'
#singularity exec --bind $mdir:/CP00 $idir/nidebian-1.1.2 bash $scripts/ps02_GLM.AudioVisAssos2words.wPSC.wNR50_afni.sh
#echo -e 'Running ps02_GLM.AudioVisAssos2words.wPSC.wTENT.wNR50_afni.sh with singularity'
#singularity exec --bind $mdir:/CP00 $idir/nidebian-1.1.2 bash $scripts/ps02_GLM.AudioVisAssos2words.wPSC.wTENT.wNR50_afni.sh
echo -e 'Running ps06_RSE_AudioVisAssos2words_timeseries_afni.sh with singularity'
singularity exec --bind $mdir:/CP00 $idir/nidebian-1.1.2 bash $scripts/ps06_RSE_AudioVisAssos2words_timeseries_afni.sh
