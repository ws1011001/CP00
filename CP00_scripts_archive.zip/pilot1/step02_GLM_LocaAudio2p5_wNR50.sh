#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-LocaAudio2p5'            # task name
spac='space-MNI152NLin2009cAsym'  # anatomical template that used for preprocessing by fMRIPrep
deno='NR50'                       # denoising strategy (J-L recommended)
hmpv="dfile_motion_${deno}"       # all head motion NRs that should be regressed out 
ortv="dfile_signal_${deno}"       # all non-motion NRs that should be regressed out
cenv='dfile_censor_FD'            # censors
nrun=1                            # number of runs
fwhm=5                            # double the voxel size (2.5 mm)
hmth=0.5                          # head motion threshold used for censoring
njob=4                            # number of processors used for GLM

wdir="$adir/$subj/$task"          # the Working folder
bold='desc-preproc_bold'          # the token for the preprocessed BOLD data (without smoothing)
regs='desc-confounds_regressors'  # the token for fMRIPrep output nuisance regressors
anat='desc-preproc_T1w_brain'     # skull-stripped anatomical image
oglm="${subj}_${task}_GLM_${deno}"        # the token for the Output GLM


# prepare data for GLM
3dDATAfMRIPrepToAFNI -fmriprep $ddir -subj $subj -task $task -nrun $nrun -deno $deno -spac $spac -cens $hmth -apqc $wdir/$oglm

# generate AFNI script
afni_proc.py -subj_id ${subj}_${task} \
  -script $wdir/${oglm}.tcsh \
  -out_dir $wdir/$oglm \
  -copy_anat $adir/$subj/${subj}_${spac}_${anat}.nii.gz \
  -anat_has_skull no \
  -dsets $wdir/${subj}_${task}_run-*_${spac}_${bold}.nii.gz \
  -blocks blur mask regress \
  -blur_size $fwhm \
  -mask_apply anat \
  -regress_polort 2 \
  -regress_local_times \
  -regress_stim_times $wdir/stimuli/${subj}_${task}_events-cond*.txt \
  -regress_stim_labels words pseudowords scrambled catch \
  -regress_basis_multi 'BLOCK(12.06,1)' 'BLOCK(12.06,1)' 'BLOCK(12.06,1)' GAM \
  -regress_motion_file $wdir/confounds/${subj}_${task}_${hmpv}.1D \
  -regress_motion_per_run \
  -regress_censor_extern $wdir/confounds/${subj}_${task}_${cenv}.1D \
  -regress_opts_3dD \
    -ortvec $wdir/confounds/${subj}_${task}_run-01_${ortv}.1D nuisance_regressors \
    -gltsym 'SYM: +words -pseudowords' -glt_label 1 words-pseudowords \
    -gltsym 'SYM: +words -scrambled' -glt_label 2 words-scrambled \
    -gltsym 'SYM: +pseudowords -scrambled' -glt_label 3 pseudowords-scrambled \
  -jobs $njob \
  -html_review_style pythonic

# modify the script nd run it
sed -e '39 {s/^/#/}' -e '46 {s/^/#/}' $wdir/${oglm}.tcsh > $wdir/${oglm}_exec.tcsh  # comment the line 39 to ignore the exist of out_dir
tcsh -xef $wdir/${oglm}_exec.tcsh 2>&1 | tee $wdir/output_${oglm}_exec.tcsh         # execute the AFNI script

# backup confounds (.1D files) for the present GLM
tar -cvzf $wdir/confounds/${oglm}.1D.tar.gz $wdir/confounds/*.1D
rm -r $wdir/confounds/*.1D
