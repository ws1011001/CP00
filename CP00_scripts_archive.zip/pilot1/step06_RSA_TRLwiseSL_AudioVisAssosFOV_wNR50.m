%% SCRIPT to do the representational similarity analysis for the AudioVisAssosFOV task with the original design. The RSA
%% will be performed on condition-wise estimates amd focus on several ROIs. 
%% clean up
close all
clear
clc

%% setup environments
% toolbox
addpath('/home/wang/Documents/MATLAB/spm8');
addpath(genpath('/home/wang/Documents/MATLAB/rsatoolbox'))
% data path and parameters
mdir='/data/agora/Chotiga_VOTmultimod/AudioVisAsso/derivatives/';  % the Main folder
adir=fullfile(mdir,'afni');  % AFNI output folder
vdir=fullfile(mdir,'multivariate');  % multiVariate analyses folder
performRSA=1;  % set switch for RSA

%% RSA settings
subjects={'sub_pilot1'};  % MATLAB structure array should contain only letters, numbers, and/or the underscore character, so replace - by _
n=length(subjects);  % number of subjects
% setup RSA parameters
dataSettings.rootPath=fullfile(vdir,'tvRSA');  % Condition-wise Volume-based ROIs-only RSA
dataSettings.analysisName='Searchlight5mm';
dataSettings.searchlightRadius=5;  % searchlight kernel radius is 5 mm
dataSettings.voxelSize=[1.754 1.754 1.75];    % 93 voxels
if ~exist(fullfile(dataSettings.rootPath,'temp_tvsRSA'),'dir')
    mkdir(fullfile(dataSettings.rootPath,'temp_tvsRSA'));
end

% trial-wise RDM models
ntrl=12
ncon=8
load(fullfile(dataSettings.rootPath,'searchlight_condition2trial_wise_models.mat'));  % load the condition-wise RDM models 'cwModels'
twModels.written=kron(cwModels.written,ones(ntrl,ntrl));
twModels.written(1:ntrl*ncon+1:end)=0;
twModels.spoken=kron(cwModels.spoken,ones(ntrl,ntrl));
twModels.spoken(1:ntrl*ncon+1:end)=0;
twModels.both=kron(cwModels.both,ones(ntrl,ntrl));
twModels.both(1:ntrl*ncon+1:end)=0;
RDMs_models=constructModelRDMs(twModels,dataSettings);


% perform RSA for each subject
if performRSA
  for i=1:n
      tic;
      temp_dataSettings=dataSettings;
      temp_dataSettings.subjectNames=subjects(i);
      % prepare fMRI data (GLM beta)
      betaDir=fullfile(temp_dataSettings.rootPath,subjects{i},'betas_afni');
      betaFiles=dir(fullfile(betaDir,'*.nii'));
      betaNames=extractfield(betaFiles,'name');  % to be used as conditionLabels
      betas=cell2struct(betaNames(:),'identifier',2);
      betas=betas';  % to be used as the first argument in the function fMRIDataPreparation()
      temp_dataSettings.betaPath=fullfile(temp_dataSettings.rootPath,'[[subjectName]]','betas_afni','[[betaIdentifier]]');
      temp_dataSettings.conditionLabels=betaNames;
      temp_rsaVols=fMRIDataPreparation(betas,temp_dataSettings);
      % prepare masks
      temp_dataSettings.maskPath=fullfile(dataSettings.rootPath,subjects{i},'masks','[[maskName]].nii');
      temp_dataSettings.maskNames={'iGrayMatter'};
      temp_rsaMasks=fMRIMaskPreparation(temp_dataSettings);
      % save to the temporaary working folder
      filename=fullfile(temp_dataSettings.rootPath,'temp_tvsRSA',strcat(dataSettings.analysisName,'_',subjects{i},'.mat'));
      save(filename,'betas','temp*');
      clear beta* temp*
      toc;
      disp(strcat(subjects(i),' data preparation done...'));
  end

  % process one session at a time
  for j=1:n
      temp_subjName=subjects{j};
      fprintf(strcat(temp_subjName,' processing......\n'));
      filename=fullfile(dataSettings.rootPath,'temp_tvsRSA',strcat(dataSettings.analysisName,'_',temp_subjName,'.mat'));
      load(filename);
      fMRISingleSearchlight(temp_rsaVols,temp_rsaMasks,RDMs_models,betas,temp_dataSettings,0);  % 0: do not save voxel-wise RDMs
      fprintf(strcat(temp_subjName,' finished......\n'));
      clear betas temp*
  end
end
