#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
rdir="$adir/$subj/individual_ROIs"  # the individual ROIs folder
lbrs="$adir/ROIs/VinckierSixROIs.1D"  # the coordinates of the Literature-Based ROIs
tdir="$wdir/${subj}_${task}_GLM.psc_wTENT_NR50"  # TENT folder
nrun=2
gmth=0.2
rads=3.5
spac='space-MNI152NLin2009cAsym'  # anatomical template that used for preprocessing by fMRIPrep

# refine individual ROIs with individual GM mask
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp")
mask="${subj}_${spac}_GM${gmth}_mask"
bref="$adir/ROIs/${subj}_${task}_${spac}_boldref.nii.gz"
if [ ! -f "$rdir/${mask}.nii.gz" ];then
  echo -e "Refining individual ROIs for subject: $subj with the individual Gray Matter mask ......"
  3dcalc -a $ddir/derivatives/fmriprep/$subj/anat/${subj}_${spac}_label-GM_probseg.nii.gz -expr "ispositive(a-$gmth)" -prefix $rdir/${mask}.nii.gz
  3dresample -master $bref -prefix $rdir/${mask}_ref-${task}.nii.gz -input $rdir/$mask.nii.gz
  for iroi in ${rois[@]};do
    3dresample -master $bref -prefix $rdir/${subj}_${iroi}_ref-${task}.nii.gz -input $rdir/${subj}_${iroi}.nii.gz
#    3dmask_tool -input $rdir/${subj}_${iroi}_ref-${task}.nii.gz -prefix $rdir/${subj}_${iroi}_ref-${task}.fill.nii.gz -fill_holes
    3dcalc -a $rdir/${subj}_${iroi}_ref-${task}.nii.gz -b $rdir/${mask}_ref-${task}.nii.gz -expr 'a*b' -prefix $rdir/${subj}_${iroi}_ref-${task}_wGM${gmth}.nii.gz
  done
else
  echo -e "Already have the GM refined ROIs."
fi

# extract time-series for each model for each ROI
declare -a glms=("${subj}_${task}_GLM.psc_NR50" "${subj}_${task}_GLM.psc_Design12_NR50")
for iglm in ${glms[@]};do
  gdir=$wdir/$iglm
  fdir="$gdir/ROIana"
  if [ ! -d $fdir ];then
    mkdir -p $fdir
  fi
  echo -e "Extracting time-series for all ROIs ......"
  for irun in $(seq 1 $nrun);do
    frun=`printf "r%02d" $irun`
    bold="pb02.${subj}_${task}.${frun}.scale+tlrc"
    # literature-based ROIs
    while read x y z l;do
      froi="ROI_Sphere${l}_${subj}_${task}.${frun}.scale.1D"
      3dmaskave -q -nball $x $y $z $rads $gdir/$bold > $fdir/$froi
    done < $lbrs
    # individual ROIs
    for iroi in ${rois[@]};do
      froi="ROI_${iroi}_${subj}_${task}.${frun}.scale.1D"
      3dmaskave -q -mask $rdir/${subj}_${iroi}_ref-${task}_wGM${gmth}.nii.gz $gdir/$bold > $fdir/$froi
    done
  done
done

# extract FIR time course for each condition for each ROI
if [ -d $tdir ];then
  declare -a cons=("SISMa" "SISMv" "SIDMa" "SIDMv" "DISMa" "DISMv" "DIDMa" "DIDMv" "catch")
  fdir="$tdir/ROIana"
  if [ ! -d $fdir ];then
    mkdir -p $fdir
  fi
  echo -e "Extracting FIR time course for all ROIs ......"
  for icon in ${cons[@]};do
    firt="TENT_IRF_${icon}.${subj}_${task}+tlrc"
    # literature-based ROIs
    while read x y z l;do
      froi="ROI_Sphere${l}_${subj}_${task}.${icon}.IRF.1D"
      3dmaskave -q -nball $x $y $z $rads $tdir/$firt > $fdir/$froi
    done < $lbrs
    # individual ROIs
    for iroi in ${rois[@]};do
     froi="ROI_${iroi}_${subj}_${task}.${icon}.IRF.1D"
     3dmaskave -q -mask $rdir/${subj}_${iroi}_ref-${task}_wGM${gmth}.nii.gz $tdir/$firt > $fdir/$froi
    done   
  done
else
  echo -e "There is no FIR model. Skip."
fi

echo -e "Finish extracting data for ROI-based analysis!"

