#!/bin/bash
# by Shuai Wang

# setup 
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
deno='NR50'                       # denoising strategy (J-L recommended)
wdir="$adir/$subj/$task"          # the Working folder
oglm="${subj}_${task}_GLM.psc_${deno}"        # the token for the Output GLM
oglt="GLT_${oglm}_Factorial.Tests"
smap="stats.${oglt}_iGrayMatter"
Pval=0.01
NN=2
NC=30
Nlabel="NN${NN}Clust${NC}"

cd $wdir/$oglm
Tval=`p2dsetstat -inset ${smap}+tlrc.'[1]' -pval $Pval -bisided -quiet`
echo -e "The T-value should be at least $Tval or -$Tval to hold the P-value lower than $Pval"
if [ ! -d "factorial" ];then
  mkdir factorial  
  3dbucket -aglueto factorial/${smap}_Tmaps ${smap}+tlrc.'[1..121(4)]'
  ConvertAFNItoNIFTI factorial/${smap}_Tmaps+tlrc factorial Tmaps
fi

cd factorial
mkdir ${Nlabel}_results
i=0
for tmap in Tmaps*;do
  3dClusterize -nosum -1Dformat -orient LPI -inset ${smap}_Tmaps+tlrc.HEAD -idat $i -ithr $i -NN $NN -clust_nvox $NC -bisided -$Tval $Tval -pref_map ${Nlabel}_results/${tmap::-4}_${Nlabel}_mask.nii.gz > ${Nlabel}_results/${tmap::-4}_${Nlabel}.1D
  3dcalc -a ${smap}_Tmaps+tlrc."[$i]" -b ${Nlabel}_results/${tmap::-4}_${Nlabel}_mask.nii.gz -expr 'a*ispositive(b)' -prefix ${Nlabel}_results/${tmap::-4}_${Nlabel}.nii.gz
  let i=$i+1
done
