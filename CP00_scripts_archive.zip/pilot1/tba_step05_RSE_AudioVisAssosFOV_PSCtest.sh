#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
tdir="$wdir/${subj}_${task}_GLM.psc_NR50"  # TENT folder
fdir="$tdir/ROIana"
tr=1.148

# refine individual ROIs with individual GM mask
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "Sphere1" "Sphere2" "Sphere3" "Sphere4" "Sphere5" "Sphere6")
for iroi in ${rois[@]};do
  idir="$fdir/$iroi"
  if [ ! -d $idir ];then
    mkdir -p $idir
  fi
  cd $idir
  3dDeconvolve -force_TR $tr -input1D $fdir/ROI_${iroi}_${subj}_${task}.r*.scale.1D \
    -censor $wdir/confounds/${subj}_${task}_${cenv}.1D \
    -ortvec $wdir/confounds/${subj}_${task}_${hmpv}.1D \
    -ortvec $wdir/confounds/${subj}_${task}_run-01_${ortv}_all.1D nuisance_regressors_run1 \
    -ortvec $wdir/confounds/${subj}_${task}_run-02_${ortv}_all.1D nuisance_regressors_run2 \
    -polort 2 \
    -local_times \
    -num_stimts 9 \
    -stim_times 1 $wdir/stimuli/${subj}_${task}_events-cond1.txt GAM -stim_label 1 SISMa \
    -stim_times 2 $wdir/stimuli/${subj}_${task}_events-cond2.txt GAM -stim_label 2 SISMv \
    -stim_times 3 $wdir/stimuli/${subj}_${task}_events-cond3.txt GAM -stim_label 3 SIDMa \
    -stim_times 4 $wdir/stimuli/${subj}_${task}_events-cond4.txt GAM -stim_label 4 SIDMv \
    -stim_times 5 $wdir/stimuli/${subj}_${task}_events-cond5.txt GAM -stim_label 5 DISMa \
    -stim_times 6 $wdir/stimuli/${subj}_${task}_events-cond6.txt GAM -stim_label 6 DISMv \
    -stim_times 7 $wdir/stimuli/${subj}_${task}_events-cond7.txt GAM -stim_label 7 DIDMa \
    -stim_times 8 $wdir/stimuli/${subj}_${task}_events-cond8.txt GAM -stim_label 8 DIDMv \
    -stim_times 9 $wdir/stimuli/${subj}_${task}_events-cond9.txt GAM -stim_label 9 catch \
    -num_glt 28 \
    -gltsym 'SYM: +SISMa -SISMv' -glt_label 1 SISMa-SISMv \
    -gltsym 'SYM: +SISMa -SIDMa' -glt_label 2 SISMa-SIDMa \
    -gltsym 'SYM: +SISMa -SIDMv' -glt_label 3 SISMa-SIDMv \
    -gltsym 'SYM: +SISMa -DISMa' -glt_label 4 SISMa-DISMa \
    -gltsym 'SYM: +SISMa -DISMv' -glt_label 5 SISMa-DISMv \
    -gltsym 'SYM: +SISMa -DIDMa' -glt_label 6 SISMa-DIDMa \
    -gltsym 'SYM: +SISMa -DIDMv' -glt_label 7 SISMa-DIDMv \
    -gltsym 'SYM: +SISMv -SIDMa' -glt_label 8 SISMv-SIDMa \
    -gltsym 'SYM: +SISMv -SIDMv' -glt_label 9 SISMv-SIDMv \
    -gltsym 'SYM: +SISMv -DISMa' -glt_label 10 SISMv-DISMa \
    -gltsym 'SYM: +SISMv -DISMv' -glt_label 11 SISMv-DISMv \
    -gltsym 'SYM: +SISMv -DIDMa' -glt_label 12 SISMv-DIDMa \
    -gltsym 'SYM: +SISMv -DIDMv' -glt_label 13 SISMv-DIDMv \
    -gltsym 'SYM: +SIDMa -SIDMv' -glt_label 14 SIDMa-SIDMv \
    -gltsym 'SYM: +SIDMa -DISMa' -glt_label 15 SIDMa-DISMa \
    -gltsym 'SYM: +SIDMa -DISMv' -glt_label 16 SIDMa-DISMv \
    -gltsym 'SYM: +SIDMa -DIDMa' -glt_label 17 SIDMa-DIDMa \
    -gltsym 'SYM: +SIDMa -DIDMv' -glt_label 18 SIDMa-DIDMv \
    -gltsym 'SYM: +SIDMv -DISMa' -glt_label 19 SIDMv-DISMa \
    -gltsym 'SYM: +SIDMv -DISMv' -glt_label 20 SIDMv-DISMv \
    -gltsym 'SYM: +SIDMv -DIDMa' -glt_label 21 SIDMv-DIDMa \
    -gltsym 'SYM: +SIDMv -DIDMv' -glt_label 22 SIDMv-DIDMv \
    -gltsym 'SYM: +DISMa -DISMv' -glt_label 23 DISMa-DISMv \
    -gltsym 'SYM: +DISMa -DIDMa' -glt_label 24 DISMa-DIDMa \
    -gltsym 'SYM: +DISMa -DIDMv' -glt_label 25 DISMa-DIDMv \
    -gltsym 'SYM: +DISMv -DIDMa' -glt_label 26 DISMv-DIDMa \
    -gltsym 'SYM: +DISMv -DIDMv' -glt_label 27 DISMv-DIDMv \
    -gltsym 'SYM: +DIDMa -DIDMv' -glt_label 28 DIDMa-DIDMv \
    -jobs 4 \
    -fout -rout -tout -vout -bout \
    -x1D ${subj}_${task}_X.xmat.1D -xjpeg ${subj}_${task}_X.jpg -x1D_uncensored ${subj}_${task}_X.nocensor.xmat.1D \
    -fitts ${subj}_${task}_fitts -errts ${subj}_${task}_errts \
    -bucket ${subj}_${task}_stats

done

