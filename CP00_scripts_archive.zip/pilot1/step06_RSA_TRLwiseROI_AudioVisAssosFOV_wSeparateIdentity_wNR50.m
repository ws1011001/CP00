%% SCRIPT to do the representational similarity analysis for the AudioVisAssosFOV task with the original design. The RSA
%% will be performed on condition-wise estimates amd focus on several ROIs. 
%% clean up
close all
clear
clc

%% setup environments
% toolbox
addpath('/home/wang/Documents/MATLAB/spm8');
addpath(genpath('/home/wang/Documents/MATLAB/rsatoolbox'))
% data path and parameters
mdir='/data/agora/Chotiga_VOTmultimod/AudioVisAsso/derivatives/';  % the Main folder
adir=fullfile(mdir,'afni');  % AFNI output folder
vdir=fullfile(mdir,'multivariate');  % multiVariate analyses folder
performRSA=1;  % set switch for RSA

%% RSA settings
subjects={'sub_pilot1_SI','sub_pilot1_DI'};  % MATLAB structure array should contain only letters, numbers, and/or the underscore character, so replace - by _
n=length(subjects);  % number of subjects
% setup RSA parameters
dataSettings.rootPath=fullfile(vdir,'tvRSA2');  % Condition-wise Volume-based ROIs-only RSA
dataSettings.analysisName='LanguageNetwork';
if ~exist(fullfile(dataSettings.rootPath,'temp_tvrRSA'),'dir')
    mkdir(fullfile(dataSettings.rootPath,'temp_tvrRSA'));
end
% ROIs
fid=fopen(fullfile(dataSettings.rootPath,'LanguageNetwork_ROIs_Labels.txt'));
ROIs=textscan(fid,'%s','delimiter','\n');
fclose(fid);
ROIs=ROIs{1};
nROI=length(ROIs);
dataSettings.maskNames=ROIs;
% perform RSA for each subject
if performRSA
  for i=1:n
      tic;
      temp_dataSettings=dataSettings;
      temp_dataSettings.subjectNames=subjects(i);
      % prepare masks
      temp_dataSettings.maskPath=fullfile(dataSettings.rootPath,subjects{i},'masks','[[maskName]].nii');
      % prepare fMRI data (GLM beta)
      betaDir=fullfile(temp_dataSettings.rootPath,subjects{i},'betas_afni');
      betaFiles=dir(fullfile(betaDir,'*.nii'));
      betaNames=extractfield(betaFiles,'name');  % to be used as conditionLabels
      betas=cell2struct(betaNames(:),'identifier',2);
      betas=betas';  % to be used as the first argument in the function fMRIDataPreparation()
      temp_dataSettings.betaPath=fullfile(temp_dataSettings.rootPath,'[[subjectName]]','betas_afni','[[betaIdentifier]]');
      temp_dataSettings.conditionLabels=betaNames;
      temp_rsaVols=fMRIDataPreparation(betas,temp_dataSettings);
      temp_rsaMasks=fMRIMaskPreparation(temp_dataSettings);
      % calculate RDMs
      temp_rsaROIs=fMRIDataMasking(temp_rsaVols,temp_rsaMasks,betas,temp_dataSettings);
      temp_dataSettings.distance='Correlation';
      temp_dataSettings.RoIColor=[0 0 1];
      temp_RDMs=constructRDMs(temp_rsaROIs,betas,temp_dataSettings);
      % plot RDMs and MDS
      temp_dataSettings.displayFigures=false;
      temp_dataSettings.saveFiguresJpg=true;    
      figureRDMs(temp_RDMs,temp_dataSettings,struct('fileName',strcat(subjects{i},'_RDMs')));   
      filename=fullfile(temp_dataSettings.rootPath,'temp_tvrRSA',strcat(subjects{i},'.mat'));
      save(filename,'betas','temp*');
      clear beta* temp*
      toc;
      disp(strcat(subjects(i),' done...'));
  end
end
