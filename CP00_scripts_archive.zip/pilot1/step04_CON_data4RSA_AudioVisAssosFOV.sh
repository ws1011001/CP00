#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso/derivatives"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/afni"       # AFNI output folder
vdir="$ddir/multivariate/cvrRSA"

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
rdir="$adir/$subj/individual_ROIs"
deno='NR50'
oglm="${subj}_${task}_GLM.psc_${deno}"  # TENT folder

# create subject folder
if [ ! -d $vdir/$subj ];then
  mkdir -p $vdir/$subj/betas_afni
  mkdir -p $vdir/$subj/masks
fi

# prepare beta estimates
3dbucket -prefix $vdir/$subj/betas_afni/betas.${subj}_${task} $wdir/$oglm/stats.${subj}_${task}+tlrc.'[1..22(3)] '
ConvertAFNItoNIFTI $vdir/$subj/betas_afni/betas.${subj}_${task}+tlrc $vdir/$subj/betas_afni con

# prepare ROI-masks
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "iGrayMatter")
for iroi in ${rois[@]};do
  froi="$rdir/${subj}_${iroi}_ref-${task}_wGM0.2.nii.gz"
  3dcopy $froi $vdir/$subj/masks/${iroi}.nii
done
cp -r $adir/ROIs/Sphere*.nii $vdir/$subj/masks

