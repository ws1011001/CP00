#!/bin/bash
# by Shuai Wang

# setup 
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
deno='NR50'                       # denoising strategy (J-L recommended)
wdir="$adir/$subj/$task"          # the Working folder
oglm="${subj}_${task}_GLM.psc_${deno}"        # the token for the Output GLM
oglt="GLT_${oglm}_4.Simple.Tests"
Pval=0.05

cd $wdir/$oglm
if [ ! -d "coactivtion" ];then
  mkdir coactivation
fi
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "iGrayMatter")
for iroi in ${rois[@]};do
  # explore the RSE for each ROIs
  sroi="stats.${oglt}_${iroi}"
  Tval=`p2dsetstat -inset ${sroi}+tlrc.'[1]' -pval $Pval -bisided -quiet`
  echo -e "For the ROI ${iroi}: the T-value should be at least $Tval or -$Tval to hold the P-value lower than $Pval"
  3dcalc -a ${sroi}+tlrc.'[1,5,9,13]' -expr "ispositive(a-$Tval)-isnegative(a+$Tval)" -prefix coactivation/${sroi}_sig.p${Pval}
  ConvertAFNItoNIFTI coactivation/${sroi}_sig.p${Pval}+tlrc coactivation ${sroi}_sig.p${Pval}
done
