#!/bin/bash
# by Shuai Wang

mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder
ddir="$mdir/AudioVisAsso"               # experiment Data folder
rdir="$ddir/derivatives"                # processed Results folder
fsli="$mdir/license.txt"                # the FSL license that needed by fMRIPrep

#dofs=(6 9 12)  # degree of freedom for BBR
dofs=(6)

for d in ${dofs[@]};do
	echo "do fMRIPrep pipeline with BBR dof $d ......"
	# send the starting email
	mutt -s "CP00 pilot1 wBBR$d start on totti" ws1011001@gmail.com < /dev/null
	
	# run fMRIPrep docker
	docker run -ti --rm \
		-v $fsli:/opt/freesurfer/license.txt:ro \
		-v $ddir:/data:ro -v $rdir:/out \
		poldracklab/fmriprep:1.5.4 /data /out/pilot1_wBBR$d participant \
		--output-spaces MNI152NLin2009cAsym \
		--fs-no-reconall \
		--bold2t1w-dof $d \
		--ignore slicetiming \
		--stop-on-first-crash \
		--write-graph
	
	# send the ending email
	mutt -s "Finish CP00 pilot1 wBBR$d" ws1011001@gmail.com < /dev/null
done
