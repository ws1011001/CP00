#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
tdir="$wdir/${subj}_${task}_GLM.psc_wTENT_NR50"  # TENT folder
fdir="$tdir/ROIana"

# refine individual ROIs with individual GM mask
#declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "Sphere1" "Sphere2" "Sphere3" "Sphere4" "Sphere5" "Sphere6")
declare -a rois=("iVWFA_cvRSA_written" "iVWFA_cvRSA_spoken" "iVWFA_tvRSA2SI_written" "iVWFA_tvRSA2DI_written" "iVWFA_tvRSA2SI_spoken" "iVWFA_tvRSA2DI_spoken") 
for iroi in ${rois[@]};do
#  1dcat $fdir/ROI_${iroi}_${subj}_${task}.*.IRF.1D > $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.1D
  # plot the FIR time course for this ROI
  1dRplot -input $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.1D \
    -save $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.pdf \
    -save.size 4000 3000 \
    -TR 1.148 \
    -title "${iroi} - FIR time Course" \
    -xax.label 'Time (seconds)' \
    -yax.label 'Percent Signal Change' \
    -col.name catch DIDMa DIDMv DISMa DISMv SIDMa SIDMv SISMa SISMv \
    -col.color 1 2 3 4 5 2 3 4 5 \
    -col.line.type 3 2 2 2 2 1 1 1 1 \
    -col.plot.type b \
    -grid.show \
    -leg.show \
    -leg.position topleft \
    -one \
    -zeros  
done

