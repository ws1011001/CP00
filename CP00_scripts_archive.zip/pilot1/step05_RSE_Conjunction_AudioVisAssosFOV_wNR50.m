%% SCRIPT to do the conjunction analysis for the AudioVisAssosFOV task with the original design, following the bash 
%% script named step05_RSE_Conjunction_AudioVisAssosFOV_wNR50.sh
%% By Shuai Wang

%% clean up
close all
clear
clc

%% setup environments
addpath('/home/wang/Documents/MATLAB/spm12');
adir='/data/agora/Chotiga_VOTmultimod/AudioVisAsso/derivatives/afni';  % AFNI output folder
subj='sub-pilot1';
task='task-AudioVisAssosFOV';
wdir=fullfile(adir,subj,task);  % the Working folder
deno='NR50';                       % denoising strategy (J-L recommended)
oglm=sprintf('%s_%s_GLM.psc_%s',subj,task,deno);  % the token for the Output GLM
oglt=sprintf('GLT_%s_4.Simple.Tests',oglm);       % the token for the Output GLTs
cdir=fullfile(wdir,oglm,'coactivation');          % the Coactivation folder

%% conjunction analysis for each ROI
% read SPM header template
V=spm_vol(fullfile(adir,subj,'individual_ROIs',sprintf('%s_iGrayMatter_ref-%s_wGM0.2.nii.gz',subj,task)));
% do it for each ROI
rois={'iVWFA','iLSTG','iRSTG','iLSTGa','iLSTGp','iGrayMatter'};
nroi=length(rois);
for iroi=1:nroi
  froi=rois{iroi};
  % read nifti in order SISMv, SISMa, SIDMv, and SIDMa
  sismv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SISMv-DISMv_GLT_0_Tstat.nii',oglt,froi));
  sisma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SISMa-DISMa_GLT_0_Tstat.nii',oglt,froi));
  sidmv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIDMv-DIDMv_GLT_0_Tstat.nii',oglt,froi));
  sidma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIDMa-DIDMa_GLT_0_Tstat.nii',oglt,froi));  
  sismv_x=spm_read_vols(spm_vol(sismv));
  sisma_x=spm_read_vols(spm_vol(sisma));
  sidmv_x=spm_read_vols(spm_vol(sidmv));
  sidma_x=spm_read_vols(spm_vol(sidma));
  % find unique patterns
  conjunction=cat(4,sismv_x,sisma_x,sidmv_x,sidma_x);
  conjunction_vec4=reshape(conjunction,[],4);
  conjunction_uvec=unique(conjunction_vec4,'rows');  % unique patterns
  conjunction_uvec(~any(conjunction_uvec,2),:)=[];   % remove the all zeros pattern (without any significance)
  conjunction_pats=zeros(size(conjunction_vec4,1),1);
  nconj=size(conjunction_uvec,1);
  conjunction_stat=[conjunction_uvec,zeros(nconj,2)];
  for iconj=1:nconj
    [~,pats]=ismember(conjunction_vec4,conjunction_uvec(iconj,:),'rows');
    conjunction_pats=conjunction_pats+pats*iconj;
    conjunction_stat(iconj,5)=sum(pats);  % number of voxels
    conjunction_stat(iconj,6)=iconj;      % ROI Index
  end
  conjunction_pats=reshape(conjunction_pats,size(sismv_x));
  % output conjunction patterns
  save(fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_conjunction.mat',oglt,froi)),'conjunction*','-v7.3');
  writetable(array2table(conjunction_stat,'VariableNames',{'SISMv','SISMa','SIDMv','SIDMa','NumVox','ROI'}),...
    fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_conjunction.csv',oglt,froi)),'Delimiter',',');
  V.fname=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_conjunction.nii',oglt,froi)); 
  spm_write_vol(V,conjunction_pats);
end

