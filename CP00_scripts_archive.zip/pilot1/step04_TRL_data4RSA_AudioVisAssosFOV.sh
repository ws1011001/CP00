#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso/derivatives"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/afni"       # AFNI output folder
vdir="$ddir/multivariate/tvRSA"

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
rdir="$adir/$subj/individual_ROIs"
deno='NR50'
oglm="${subj}_${task}_GLM.psc_${deno}"  # TENT folder

# create subject folder
if [ ! -d $vdir/$subj ];then
  mkdir -p $vdir/$subj/betas_afni
  mkdir -p $vdir/$subj/masks
fi

# prepare trial-wise estimates for the RSA
declare -a cons=("SISMa" "SISMv" "SIDMa" "SIDMv" "DISMa" "DISMv" "DIDMa" "DIDMv")
i=1
for icon in ${cons[@]};do
  cprefix=`printf "con%02d" $i`
  ConvertAFNItoNIFTI $wdir/$oglm/trial-wise_estimates/LSS.stats.${subj}_${task}_${cprefix}_${icon}+tlrc $vdir/$subj/betas_afni ${cprefix}_trl
  let i=$i+1
done

# prepare ROI-masks
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "iGrayMatter")
for iroi in ${rois[@]};do
  froi="$rdir/${subj}_${iroi}_ref-${task}_wGM0.2.nii.gz"
  3dcopy $froi $vdir/$subj/masks/${iroi}.nii
done
