#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
wdir="$adir/$subj/$task"          # the Working folder
deno='NR50'                       # denoising strategy (J-L recommended)
hmpv="dfile_motion_${deno}"       # all head motion NRs that should be regressed out 
ortv="dfile_signal_${deno}"       # all non-motion NRs that should be regressed out
cenv='dfile_censor_FD'            # censors
oglm="${subj}_${task}_GLM.psc_${deno}"  # TENT folder
fdir="$wdir/$oglm/ROIana"
tr=1.148

## prepare nuisance regressors
#tar -mvxf $wdir/confounds/${oglm}.1D.tar.gz -C $wdir/confounds
#cp -r $wdir/confounds/${subj}_${task}_${cenv}.1D $fdir
#1d_tool.py -infile $wdir/confounds/${subj}_${task}_${hmpv}.1D -set_nruns 2 -demean -write $fdir/${subj}_${task}_${hmpv}_demean.1D 
#1d_tool.py -infile $fdir/${subj}_${task}_${hmpv}_demean.1D -set_nruns 2 -split_into_pad_runs $fdir/${subj}_${task}_${hmpv}_demean_all
#1d_tool.py -infile $wdir/confounds/${subj}_${task}_run-01_${ortv}.1D -demean -write $fdir/${subj}_${task}_run-01_${ortv}_demean.1D
#1d_tool.py -infile $wdir/confounds/${subj}_${task}_run-02_${ortv}.1D -demean -write $fdir/${subj}_${task}_run-02_${ortv}_demean.1D
#1d_tool.py -infile $fdir/${subj}_${task}_run-01_${ortv}_demean.1D -pad_into_many_runs 1 2 -write $fdir/${subj}_${task}_run-01_${ortv}_demean_all.1D
#1d_tool.py -infile $fdir/${subj}_${task}_run-02_${ortv}_demean.1D -pad_into_many_runs 2 2 -write $fdir/${subj}_${task}_run-02_${ortv}_demean_all.1D
#rm -r $wdir/confounds/*.1D
#
## generate the global timing
#for icond in $wdir/stimuli/${subj}_${task}_events-cond?.txt;do
#  timing_tool.py -timing $icond -local_to_global ${icond::-4}_global.txt -run_len 555.632 555.632
#done

# run GLM and GLT for ROI-based time-series
#declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "Sphere1" "Sphere2" "Sphere3" "Sphere4" "Sphere5" "Sphere6")
declare -a rois=("iVWFA_cvRSA_written" "iVWFA_cvRSA_spoken" "iVWFA_tvRSA2SI_written" "iVWFA_tvRSA2DI_written" "iVWFA_tvRSA2SI_spoken" "iVWFA_tvRSA2DI_spoken")
cd $fdir
for iroi in ${rois[@]};do
  if [ ! -d $iroi ];then
    mkdir -p $iroi
  fi
  cat ROI_${iroi}_${subj}_${task}.r*.scale.1D > $iroi/ROI_${iroi}_${subj}_${task}.all.scale.1D
  3dDeconvolve -force_TR $tr -input1D $iroi/ROI_${iroi}_${subj}_${task}.all.scale.1D \
    -censor ${subj}_${task}_${cenv}.1D \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r01.1D head_motion_run1 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r02.1D head_motion_run2 \
    -ortvec ${subj}_${task}_run-01_${ortv}_demean_all.1D nuisance_regressors_run1 \
    -ortvec ${subj}_${task}_run-02_${ortv}_demean_all.1D nuisance_regressors_run2 \
    -polort 2 \
    -global_times \
    -num_stimts 9 \
    -stim_times 1 $wdir/stimuli/${subj}_${task}_events-cond1_global.txt GAM -stim_label 1 SISMa \
    -stim_times 2 $wdir/stimuli/${subj}_${task}_events-cond2_global.txt GAM -stim_label 2 SISMv \
    -stim_times 3 $wdir/stimuli/${subj}_${task}_events-cond3_global.txt GAM -stim_label 3 SIDMa \
    -stim_times 4 $wdir/stimuli/${subj}_${task}_events-cond4_global.txt GAM -stim_label 4 SIDMv \
    -stim_times 5 $wdir/stimuli/${subj}_${task}_events-cond5_global.txt GAM -stim_label 5 DISMa \
    -stim_times 6 $wdir/stimuli/${subj}_${task}_events-cond6_global.txt GAM -stim_label 6 DISMv \
    -stim_times 7 $wdir/stimuli/${subj}_${task}_events-cond7_global.txt GAM -stim_label 7 DIDMa \
    -stim_times 8 $wdir/stimuli/${subj}_${task}_events-cond8_global.txt GAM -stim_label 8 DIDMv \
    -stim_times 9 $wdir/stimuli/${subj}_${task}_events-cond9_global.txt GAM -stim_label 9 catch \
    -num_glt 4 \
    -gltsym 'SYM: +SISMa -DISMa' -glt_label 1 SISMa-DISMa \
    -gltsym 'SYM: +SISMv -DISMv' -glt_label 2 SISMv-DISMv \
    -gltsym 'SYM: +SIDMa -DIDMa' -glt_label 3 SIDMa-DIDMa \
    -gltsym 'SYM: +SIDMv -DIDMv' -glt_label 4 SIDMv-DIDMv \
    -jobs 4 \
    -fout -rout -tout -vout \
    -x1D $iroi/ROI_${iroi}_X.xmat.1D -xjpeg $iroi/ROI_${iroi}_X.jpg -x1D_uncensored $iroi/ROI_${iroi}_X.nocensor.xmat.1D \
    -fitts $iroi/ROI_${iroi}_fitts -errts $iroi/ROI_${iroi}_errts \
    -bucket $iroi/ROI_${iroi}_stats > $iroi/ROI_${iroi}_reports.txt
done
