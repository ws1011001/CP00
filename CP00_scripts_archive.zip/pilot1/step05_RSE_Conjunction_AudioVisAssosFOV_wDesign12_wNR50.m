%% SCRIPT to do the conjunction analysis for the AudioVisAssosFOV task with the original design, following the bash 
%% script named step05_RSE_Conjunction_AudioVisAssosFOV_wNR50.sh
%% By Shuai Wang

%% clean up
close all
clear
clc

%% setup environments
addpath('/home/wang/Documents/MATLAB/spm12');
adir='/data/agora/Chotiga_VOTmultimod/AudioVisAsso/derivatives/afni';  % AFNI output folder
subj='sub-pilot1';
task='task-AudioVisAssosFOV';
wdir=fullfile(adir,subj,task);  % the Working folder
deno='NR50';                       % denoising strategy (J-L recommended)
oglm=sprintf('%s_%s_GLM.psc_Design12_%s',subj,task,deno);  % the token for the Output GLM
oglt=sprintf('GLT_%s_10.Simple.Tests',oglm);       % the token for the Output GLTs
cdir=fullfile(wdir,oglm,'coactivation');          % the Coactivation folder

%% conjunction analysis for each ROI
% read SPM header template
V=spm_vol(fullfile(adir,subj,'individual_ROIs',sprintf('%s_iGrayMatter_ref-%s_wGM0.2.nii.gz',subj,task)));
% do it for each ROI
rois={'iVWFA','iLSTG','iRSTG','iLSTGa','iLSTGp','iGrayMatter'};
nroi=length(rois);

%ncon=2;  % SIv and SIa
%statsnames={'SIv','SIa','NumVox','ROI'};suffix='conjunctionType1';

ncon=4;  % [SIvSMv, SIvDMv, SIaSMa, SIaDMa] OR [SISMv, SISMa, SIDMv, SIDMa]
%statsnames={'SIvSMv','SIvDMv','SIaSMa','SIaDMa','NumVox','ROI'};suffix='conjunctionType2';
statsnames={'SISMv','SISMa','SIDMv','SIDMa','NumVox','ROI'};suffix='conjunctionType3';

%ncon=10;  % SIv, SIa, SIvSMv, SIvDMv, SIaSMa, SIaDMa, SISMv, SISMa, SIDMv, and SIDMa
%statsnames={'SIv','SIa','SIvSMv','SIvDMv','SIaSMa','SIaDMa','SISMv','SISMa','SIDMv','SIDMa','NumVox','ROI'};
%suffix='conjunction';
for iroi=1:nroi
  froi=rois{iroi};
  % read nifti in order of SIv, SIa, SIvSMv, SIvDMv, SIaSMa, SIaDMa, SISMv, SISMa, SIDMv, and SIDMa
  siv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIv1-DIv1_GLT_0_Tstat.nii',oglt,froi));
  sia=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIa1-DIa1_GLT_0_Tstat.nii',oglt,froi));
  sivsmv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIv1-SISMv2_GLT_0_Tstat.nii',oglt,froi));
  sivdmv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIv1-SIDMv2_GLT_0_Tstat.nii',oglt,froi));
  siasma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIa1-SISMa2_GLT_0_Tstat.nii',oglt,froi));
  siadma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIa1-SIDMa2_GLT_0_Tstat.nii',oglt,froi));  
  sismv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SISMv-DISMv_GLT_0_Tstat.nii',oglt,froi));
  sisma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SISMa-DISMa_GLT_0_Tstat.nii',oglt,froi));
  sidmv=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIDMv-DIDMv_GLT_0_Tstat.nii',oglt,froi));
  sidma=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_SIDMa-DIDMa_GLT_0_Tstat.nii',oglt,froi));  
  siv_x=spm_read_vols(spm_vol(siv));
  sia_x=spm_read_vols(spm_vol(sia));
  sivsmv_x=spm_read_vols(spm_vol(sivsmv));
  sivdmv_x=spm_read_vols(spm_vol(sivdmv));
  siasma_x=spm_read_vols(spm_vol(siasma));
  siadma_x=spm_read_vols(spm_vol(siadma));  
  sismv_x=spm_read_vols(spm_vol(sismv));
  sisma_x=spm_read_vols(spm_vol(sisma));
  sidmv_x=spm_read_vols(spm_vol(sidmv));
  sidma_x=spm_read_vols(spm_vol(sidma));
  % find unique patterns
  %conjunction=cat(4,siv_x,sia_x);
  %conjunction=cat(4,sivsmv_x,sivdmv_x,siasma_x,siadma_x);
  conjunction=cat(4,sismv_x,sisma_x,sidmv_x,sidma_x);
  %conjunction=cat(4,siv_x,sia_x,sivsmv_x,sivdmv_x,siasma_x,siadma_x,sismv_x,sisma_x,sidmv_x,sidma_x);
  
  conjunction_vecs=reshape(conjunction,[],ncon);
  conjunction_uvec=unique(conjunction_vecs,'rows');  % unique patterns
  conjunction_uvec(~any(conjunction_uvec,2),:)=[];   % remove the all zeros pattern (without any significance)
  conjunction_pats=zeros(size(conjunction_vecs,1),1);
  nconj=size(conjunction_uvec,1);
  conjunction_stat=[conjunction_uvec,zeros(nconj,2)];
  for iconj=1:nconj
    [~,pats]=ismember(conjunction_vecs,conjunction_uvec(iconj,:),'rows');
    conjunction_pats=conjunction_pats+pats*iconj;
    conjunction_stat(iconj,ncon+1)=sum(pats);  % number of voxels
    conjunction_stat(iconj,ncon+2)=iconj;      % ROI Index
  end
  conjunction_pats=reshape(conjunction_pats,size(sismv_x));
  % output conjunction patterns
  save(fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_%s.mat',oglt,froi,suffix)),'conjunction*','-v7.3');
  writetable(array2table(conjunction_stat,'VariableNames',statsnames),fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_%s.csv',oglt,froi,suffix)),'Delimiter',',');
  V.fname=fullfile(cdir,sprintf('stats.%s_%s_sig.p0.05_%s.nii',oglt,froi,suffix)); 
  spm_write_vol(V,conjunction_pats);
end

