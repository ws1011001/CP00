#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/agora/Chotiga_VOTmultimod'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot1'                 # subject ID (should be a list)
task='task-AudioVisAssosFOV'            # task name
dsgn='Design12'                   # design name
deno='NR50'                       # denoising strategy (J-L recommended)
njob=4                            # number of processors used for GLM

wdir="$adir/$subj/$task"          # the Working folder
oglm="${subj}_${task}_GLM.psc_${dsgn}_${deno}"        # the token for the Output GLM


cd $wdir/$oglm
# perform four simple RS tests
oglt="GLT_${oglm}_10.Simple.Tests"
3dDeconvolve -xrestore stats.${subj}_${task}.xsave \
  -num_glt 10 \
	-gltsym 'SYM: +SIa1 -DIa1' -glt_label 1 SIa1-DIa1 \
	-gltsym 'SYM: +SIv1 -DIv1' -glt_label 2 SIv1-DIv1 \
	-gltsym 'SYM: +SIa1 -SISMa2' -glt_label 3 SIa1-SISMa2 \
	-gltsym 'SYM: +SIv1 -SISMv2' -glt_label 4 SIv1-SISMv2 \
	-gltsym 'SYM: +SIa1 -SIDMa2' -glt_label 5 SIa1-SIDMa2 \
	-gltsym 'SYM: +SIv1 -SIDMv2' -glt_label 6 SIv1-SIDMv2 \
  -gltsym 'SYM: +SISMa2 -DISMa2' -glt_label 7 SISMa-DISMa \
  -gltsym 'SYM: +SISMv2 -DISMv2' -glt_label 8 SISMv-DISMv \
  -gltsym 'SYM: +SIDMa2 -DIDMa2' -glt_label 9 SIDMa-DIDMa \
  -gltsym 'SYM: +SIDMv2 -DIDMv2' -glt_label 10 SIDMv-DIDMv \
  -jobs $njob \
  -fout -rout -vout -tout \
  -bucket stats.${oglt}
# explore the RSE for each ROIs
declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "iGrayMatter")
for iroi in ${rois[@]};do
  froi="$adir/$subj/individual_ROIs/${subj}_${iroi}_ref-${task}_wGM0.2.nii.gz"
  sroi="${oglt}_${iroi}"
  3dcalc -a stats.${oglt}+tlrc. -b $froi -expr 'a*b' -prefix stats.${sroi}
done
