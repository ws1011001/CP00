## ---------------------------
## ps05_MVPA_AudioVisAssos1word_Friedman_nilearn.py 
##
## SCRIPT to compare searchlight classifiers by using Friedman test and post-hoc Nemenyi test
##
## By Shuai Wang, 
##
## ---------------------------
## Notes:
##   
##
## ---------------------------

## clean up
## ---------------------------

## set environment (packages, functions, working path etc.)
# load up packages
import os
import pandas as pd
import numpy as np
import scikit_posthocs as sp
from nilearn import image, masking
from scipy import stats
# setup path
mdir='/scratch/swang/agora/CP00/AudioVisAsso'        # the project main folder
#mdir='/data/mesocentre/data/agora/CP00/AudioVisAsso'        # the project main folder
ddir=os.path.join(mdir,'derivatives')
vdir=os.path.join(ddir,'multivariate')  # multivariate analyses folder
## ---------------------------

## read subjects information and MVPA parameters
# read subjects info
sfile=os.path.join(vdir,'participants.tsv')  # subjects list
subjects=pd.read_table(sfile).set_index('participant_id')
clf_tokens=['lda','gnb','svclin','svcrbf']  # classifier tokens and order
nclfs=len(clf_tokens)
modal_tokens=['aud','vis','aud2vis','vis2aud']
#mask_token='iLVOT'
mask_token='iGMepi'
## ---------------------------

## compare searchlight classifiers by using Friedman test and posthoc Nemenyi tests
for modal in modal_tokens:
  fmodal="%s/tvsMVPA_LOROCV_%s_ComparisonClfs_%s.csv" % (vdir,mask_token,modal)
  fid=open(fmodal,'w')
  fid.write("Subject,bestClassifier,ACC_lda,ACC_gnb,ACC_svclin,ACC_svcrbf,FriedmanP,hocP1,hocP2,hocP3,hocP4,hocP5,hocP6\n")
  fid.close()
  # compare searchlight classifiers for each subject
  for subj in subjects.index[:]:
    print("compare %d searchlight classifiers in %s modality: %s for subject: %s ......" % (nclfs,modal,clf_tokens,subj))
    # setup subject path
    sdir=os.path.join(vdir,subj)
    pdir=os.path.join(sdir,'tvsMVPC')     # Trial-wise Volume-based Searchlight MVPC
    # load up mask
    mfile=os.path.join(sdir,'masks',"%s.nii" % mask_token)  # GM mask file (individual GM with EPI constrains)
    mask=image.load_img(mfile)
    # read ACC maps
    fclf_lda="%s/%s_%s_MVPA_lda_LOROCV_ACC_%s.nii.gz" % (pdir,subj,mask_token,modal)
    fclf_gnb="%s/%s_%s_MVPA_gnb_LOROCV_ACC_%s.nii.gz" % (pdir,subj,mask_token,modal)
    fclf_svclin="%s/%s_%s_MVPA_svclin_LOROCV_ACC_%s.nii.gz" % (pdir,subj,mask_token,modal)
    fclf_svcrbf="%s/%s_%s_MVPA_svcrbf_LOROCV_ACC_%s.nii.gz" % (pdir,subj,mask_token,modal)
    clf_lda=image.load_img(fclf_lda)
    clf_gnb=image.load_img(fclf_gnb)
    clf_svclin=image.load_img(fclf_svclin)
    clf_svcrbf=image.load_img(fclf_svcrbf)
    # constrain and reshape ACC maps by mask
    clf_lda_vec=masking.apply_mask(clf_lda,mask)
    clf_gnb_vec=masking.apply_mask(clf_gnb,mask)
    clf_svclin_vec=masking.apply_mask(clf_svclin,mask)
    clf_svcrbf_vec=masking.apply_mask(clf_svcrbf,mask)
    # Friedman test and posthoc Nemenyi tests
    fchisq,fp=stats.friedmanchisquare(clf_lda_vec,clf_gnb_vec,clf_svclin_vec,clf_svcrbf_vec)
    clfs_vec=np.column_stack((clf_lda_vec,clf_gnb_vec,clf_svclin_vec,clf_svcrbf_vec))
    clfs_acc_mean=np.mean(clfs_vec,axis=0)
    clfs_acc_diff=clfs_acc_mean[np.newaxis,:]-clfs_acc_mean[:,np.newaxis]
    clfs_best=clf_tokens[clfs_acc_mean.argmax()]
    clfs_p=sp.posthoc_nemenyi_friedman(clfs_vec)  # posthoc Nemenyi tests
    clfs_p=np.array(clfs_p)
    # output results for each subject
    fid=open(fmodal,'a')
    fid.write("%s,%s,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f\n" % (subj,clfs_best,clfs_acc_mean[0],clfs_acc_mean[1],clfs_acc_mean[2],clfs_acc_mean[3],fp,clfs_p[0,1],clfs_p[0,2],clfs_p[0,3],clfs_p[1,2],clfs_p[1,3],clfs_p[2,3]))
    fid.close()
    # output Nemenyi matrices for each subject
    df_clfs_acc_diff=pd.DataFrame(clfs_acc_diff,index=clf_tokens,columns=clf_tokens)
    f_clfs_acc_diff="%s/%s_%s_MVPA_LOROCV_ComparisonClfsACC_%s.csv" % (pdir,subj,mask_token,modal)
    df_clfs_acc_diff.to_csv(f_clfs_acc_diff,index=True,header=True,sep=',')
    df_clfs_p=pd.DataFrame(clfs_p,index=clf_tokens,columns=clf_tokens)
    f_clfs_p="%s/%s_%s_MVPA_LOROCV_ComparisonClfsPval_%s.csv" % (pdir,subj,mask_token,modal)
    df_clfs_p.to_csv(f_clfs_p,index=True,header=True,sep=',')
## ---------------------------    

