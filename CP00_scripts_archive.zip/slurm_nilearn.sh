#!/bin/bash

#SBATCH -J MVPA
#SBATCH -p skylake
#SBATCH --nodes=1
#SBATCH -A a187
#SBATCH -t 12:00:00
#SBATCH --cpus-per-task=16
#SBATCH --mem=128gb
#SBATCH -o ./skylake_log/ps05_MVPA_%j.out
#SBATCH -e ./skylake_log/ps05_MVPA_%j.err
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ws1011001@gmail.com
#SBATCH --mail-type=BEGIN,END

# processing log
#echo “Running ps05_MVPA_AudioVisAssos1word_Searchlight_nilearn.py ......”
#conda run --name base python ps05_MVPA_AudioVisAssos1word_Searchlight_nilearn.py
echo “Running ps05_MVPA_AudioVisAssos1word_Friedman_nilearn.py ......”
conda run --name base python ps05_MVPA_AudioVisAssos1word_Friedman_nilearn.py

