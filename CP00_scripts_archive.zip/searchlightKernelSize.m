function [sphereSize, sphere] = searchlightKernelSize(searchlightRad_mm, voxSize_mm)

  rad_vox=searchlightRad_mm./voxSize_mm;
	minMargin_vox=floor(rad_vox);
	[x,y,z]=meshgrid(-minMargin_vox(1):minMargin_vox(1),-minMargin_vox(2):minMargin_vox(2),-minMargin_vox(3):minMargin_vox(3));
	sphere=((x*voxSize_mm(1)).^2+(y*voxSize_mm(2)).^2+(z*voxSize_mm(3)).^2)<=(searchlightRad_mm^2);  % volume with sphere voxels marked 1 and the outside 0
	sphereSize=nnz(sphere);
end