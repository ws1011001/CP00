#!/bin/bash
# by Shuai Wang

# setup 
mdir='/data/mesocentre/data/agora/CP00/AudioVisAsso'  # the project Main folder @totti
adir="$mdir/derivatives/afni"       # AFNI output folder
subj='sub-pilot2rc'                 # subject ID (should be a list)
task='task-AudioVisAssos2words'            # task name
deno='NR50'                       # denoising strategy (J-L recommended)
wdir="$adir/$subj/$task"          # the Working folder
oglm="${subj}_${task}_GLM.wPSC.w${deno}"        # the token for the Output GLM

njob=4                            # number of processors used for GLM
rdir="$adir/$subj/individual_ROIs"                   # the individual ROIs folder
mask="$rdir/sub-pilot2rc_iGrayMatter_ref-task-AudioVisAssos1word_wGM0.2.nii.gz"
testSimple=true
testFactor=false

cd $wdir/$oglm
if $testSimple;then
  # perform four simple RS tests 
  oglt="GLT_${oglm}_Simple.Tests"
  3dDeconvolve -xrestore stats.${subj}_${task}.xsave \
    -num_glt 4 \
  	-gltsym 'SYM: +SISMa -DISMa' -glt_label 1 SISMa-DISMa \
  	-gltsym 'SYM: +SISMv -DISMv' -glt_label 2 SISMv-DISMv \
  	-gltsym 'SYM: +SIDMa -DIDMa' -glt_label 3 SIDMa-DIDMa \
  	-gltsym 'SYM: +SIDMv -DIDMv' -glt_label 4 SIDMv-DIDMv \
    -jobs $njob \
    -fout -rout -vout -tout \
    -bucket stats_${oglt}
  # explore the RSE within the GM
  3dcalc -a stats_${oglt}+tlrc. -b $mask -expr 'a*b' -prefix stats.GM_${oglt}
fi
if $testFactor;then
  # perform four simple RS tests 
  oglt="GLT_${oglm}_Factorial.Tests"
  3dDeconvolve -xrestore stats.${subj}_${task}.xsave \
    -num_glt 31 \
  	-gltsym 'SYM: +SISMa +SISMv +SIDMa +SIDMv -DISMa -DISMv -DIDMa -DIDMv' -glt_label 1 MainEffectIdentity \
  	-gltsym 'SYM: +SISMa +SISMv +DISMa +DISMv -SIDMa -SIDMv -DIDMa -DIDMv' -glt_label 2 MainEffectTransition \
  	-gltsym 'SYM: +SISMa +SIDMa +DISMa +DIDMa -SISMv -SIDMv -DISMv -DIDMv' -glt_label 3 MainEffectModality \
  	-gltsym 'SYM: +SISMa +SISMv +DIDMa +DIDMv -SIDMa -SIDMv -DISMa -DISMv' -glt_label 4 InteractionIdentityTransition \
    -gltsym 'SYM: +SISMa +SIDMa +DISMv +DIDMv -SISMv -SIDMv -DISMa -DIDMa' -glt_label 5 InteractionIdentityModality \
    -gltsym 'SYM: +SISMa +DISMa +SIDMv +DIDMv -SISMv -DISMv -SIDMa -DIDMa' -glt_label 6 InteractionTransitionModality \
    -gltsym 'SYM: +SISMa +DIDMa +SIDMv +DISMv -SIDMa -DISMa -SISMv -DIDMv' -glt_label 7 InteractionIdentityTransitionModality \
    -gltsym 'SYM: +SISMa +SIDMa -DISMa -DIDMa' -glt_label 8 SimpleRSE_Identity_a \
    -gltsym 'SYM: +SISMv +SIDMv -DISMv -DIDMv' -glt_label 9 SimpleRSE_Identity_v \
    -gltsym 'SYM: +SISMa +SISMv -DISMa -DISMv' -glt_label 10 SimpleRSE_Identity_SM \
    -gltsym 'SYM: +SIDMa +SIDMv -DIDMa -DIDMv' -glt_label 11 SimpleRSE_Identity_DM \
    -gltsym 'SYM: +SISMa -DISMa' -glt_label 12 SimpleRSE_Identity_a_SM \
    -gltsym 'SYM: +SIDMa -DIDMa' -glt_label 13 SimpleRSE_Identity_a_DM \
    -gltsym 'SYM: +SISMv -DISMv' -glt_label 14 SimpleRSE_Identity_v_SM \
    -gltsym 'SYM: +SIDMv -DIDMv' -glt_label 15 SimpleRSE_Identity_v_DM \
    -gltsym 'SYM: +SISMa +DISMa -SIDMa -DIDMa' -glt_label 16 SimpleRSE_Transition_a \
    -gltsym 'SYM: +SISMv +DISMv -SIDMv -DIDMv' -glt_label 17 SimpleRSE_Transition_v \
    -gltsym 'SYM: +SISMa +SISMv -SIDMa -SIDMv' -glt_label 18 SimpleRSE_Transition_SI \
    -gltsym 'SYM: +DISMa +DISMv -DIDMa -DIDMv' -glt_label 19 SimpleRSE_Transition_DI \
    -gltsym 'SYM: +SISMa -SIDMa' -glt_label 20 SimpleRSE_Transition_a_SI \
    -gltsym 'SYM: +DISMa -DIDMa' -glt_label 21 SimpleRSE_Transition_a_DI \
    -gltsym 'SYM: +SISMv -SIDMv' -glt_label 22 SimpleRSE_Transition_v_SI \
    -gltsym 'SYM: +DISMv -DIDMv' -glt_label 23 SimpleRSE_Transition_v_DI \
    -gltsym 'SYM: +SISMa +DISMa -SISMv -DISMv' -glt_label 24 SimpleRSE_Modality_SM \
    -gltsym 'SYM: +SIDMa +DIDMa -SIDMv -DIDMv' -glt_label 25 SimpleRSE_Modality_DM \
    -gltsym 'SYM: +SISMa +SIDMa -SISMv -SIDMv' -glt_label 26 SimpleRSE_Modality_SI \
    -gltsym 'SYM: +DISMa +DIDMa -DISMv -DIDMv' -glt_label 27 SimpleRSE_Modality_DI \
    -gltsym 'SYM: +SISMa -SISMv' -glt_label 28 SimpleRSE_Modality_SM_SI \
    -gltsym 'SYM: +DISMa -DISMv' -glt_label 29 SimpleRSE_Modality_SM_DI \
    -gltsym 'SYM: +SIDMa -SIDMv' -glt_label 30 SimpleRSE_Modality_DM_SI \
    -gltsym 'SYM: +DIDMa -DIDMv' -glt_label 31 SimpleRSE_Modality_DM_DI \
    -jobs $njob \
    -fout -rout -vout -tout \
    -bucket stats.${oglt}
  # explore the RSE for each ROIs
  declare -a rois=("iVWFA" "iLSTG" "iRSTG" "iLSTGa" "iLSTGp" "iGrayMatter")
  for iroi in ${rois[@]};do
    froi="$adir/$subj/individual_ROIs/${subj}_${iroi}_ref-${task}_wGM0.2.nii.gz"
    sroi="${oglt}_${iroi}"
    3dcalc -a stats.${oglt}+tlrc. -b $froi -expr 'a*b' -prefix stats.${sroi}
  done
fi
