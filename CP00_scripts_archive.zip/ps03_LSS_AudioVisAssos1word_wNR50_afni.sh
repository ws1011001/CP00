#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/mesocentre/data/agora/CP00'  # the project Main folder'
ddir="$mdir/AudioVisAsso"               # experiment Data folder (BIDS put into fMRIPrep)
adir="$ddir/derivatives/afni"       # AFNI output folder

# processing parameters
njob=4                            # number of processors used for GLM
subj='sub-pilot2rc'                 # subject ID (should be a list)
task='task-AudioVisAssos1word'            # task name
spac='space-MNI152NLin2009cAsym'  # anatomical template that used for preprocessing by fMRIPrep
deno='NR50'                       # denoising strategy (J-L recommended)
hmpv="dfile_motion_${deno}"       # all head motion NRs that should be regressed out 
ortv="dfile_signal_${deno}"       # all non-motion NRs that should be regressed out
cenv='dfile_censor_FD'            # censors
tr=1.17
nrun=5                            # number of runs
ntp=973
lrun=(192 198 193 194 196)
drun=(224.64 231.66 225.81 226.98 229.32)

wdir="$adir/$subj/$task"          # the Working folder
oglm="${subj}_${task}_GLM.wPSC.w${deno}"        # the token for the Output GLM, psc means "percent signal change"
ldir="$wdir/$oglm/trial-wise_estimates"

# prepare data for 3dLSS
if [ ! -d $ldir ];then
  mkdir -p $ldir
  cp -r $wdir/$oglm/stimuli $ldir
fi
cd $ldir  # # enter the LSS working directory
echo -e "# enter the LSS working directory..."
3dTcat -prefix LSS.${subj}_${task}.all.scale $wdir/$oglm/pb02.${subj}_${task}.r*.scale+tlrc.HEAD  # concatenate all scaled runs
3dcalc -a $wdir/$oglm/mask_epi_anat.${subj}_${task}+tlrc. -b $adir/$subj/individual_ROIs/${subj}_iGrayMatter_ref-${task}_wGM0.2.nii.gz -expr 'a*b' -prefix ${subj}_EPI_GM_mask4LSS

# prepare nuisance regressors
tar -mvxf $wdir/confounds/${oglm}.1D.tar.gz -C $wdir/confounds
cp -r $wdir/confounds/${subj}_${task}_${cenv}.1D $ldir
1d_tool.py -infile $wdir/confounds/${subj}_${task}_${hmpv}.1D -set_run_lengths ${lrun[*]} -demean -write ${subj}_${task}_${hmpv}_demean.1D
1d_tool.py -infile ${subj}_${task}_${hmpv}_demean.1D -set_run_lengths ${lrun[*]} -split_into_pad_runs ${subj}_${task}_${hmpv}_demean_all
for irun in $(seq 1 $nrun);do
  frun=`printf "%02d" $irun`
  1d_tool.py -infile $wdir/confounds/${subj}_${task}_run-${frun}_${ortv}.1D -demean -write ${subj}_${task}_run-${frun}_${ortv}_demean.1D
  1d_tool.py -infile ${subj}_${task}_run-${frun}_${ortv}_demean.1D -pad_into_many_runs $irun $nrun -set_run_lengths ${lrun[*]} -write ${subj}_${task}_run-${frun}_${ortv}_demean_all.1D
done
rm -r $wdir/confounds/*.1D

# generate the global timing
for icond in stimuli/${subj}_${task}_events-cond?.txt;do
  timing_tool.py -timing $icond -local_to_global ${icond::-4}_global.txt -run_len ${drun[*]}
done

# create the design matrix for each condition
# WA
cprefix='con1_WA'
3dDeconvolve -nodata $ntp $tr \
    -censor ${subj}_${task}_${cenv}.1D \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r01.1D head_motion_run1 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r02.1D head_motion_run2 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r03.1D head_motion_run3 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r04.1D head_motion_run4 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r05.1D head_motion_run5 \
    -ortvec ${subj}_${task}_run-01_${ortv}_demean_all.1D nuisance_regressors_run1 \
    -ortvec ${subj}_${task}_run-02_${ortv}_demean_all.1D nuisance_regressors_run2 \
    -ortvec ${subj}_${task}_run-03_${ortv}_demean_all.1D nuisance_regressors_run3 \
    -ortvec ${subj}_${task}_run-04_${ortv}_demean_all.1D nuisance_regressors_run4 \
    -ortvec ${subj}_${task}_run-05_${ortv}_demean_all.1D nuisance_regressors_run5 \
    -polort 2 \
    -global_times \
    -num_stimts 4 \
    -stim_times_IM 1 stimuli/${subj}_${task}_events-cond1_global.txt GAM -stim_label 1 WA \
    -stim_times 2 stimuli/${subj}_${task}_events-cond2_global.txt GAM -stim_label 2 WV \
    -stim_times 3 stimuli/${subj}_${task}_events-cond3_global.txt GAM -stim_label 3 PA \
    -stim_times 4 stimuli/${subj}_${task}_events-cond4_global.txt GAM -stim_label 4 PV \
    -jobs $njob \
    -x1D ${cprefix}_X.xmat.1D -xjpeg ${cprefix}_X.jpg -x1D_uncensored ${cprefix}_X.nocensor.xmat.1D \
    -x1D_stop
# WV
cprefix='con2_WV'
3dDeconvolve -nodata $ntp $tr \
    -censor ${subj}_${task}_${cenv}.1D \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r01.1D head_motion_run1 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r02.1D head_motion_run2 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r03.1D head_motion_run3 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r04.1D head_motion_run4 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r05.1D head_motion_run5 \
    -ortvec ${subj}_${task}_run-01_${ortv}_demean_all.1D nuisance_regressors_run1 \
    -ortvec ${subj}_${task}_run-02_${ortv}_demean_all.1D nuisance_regressors_run2 \
    -ortvec ${subj}_${task}_run-03_${ortv}_demean_all.1D nuisance_regressors_run3 \
    -ortvec ${subj}_${task}_run-04_${ortv}_demean_all.1D nuisance_regressors_run4 \
    -ortvec ${subj}_${task}_run-05_${ortv}_demean_all.1D nuisance_regressors_run5 \
    -polort 2 \
    -global_times \
    -num_stimts 4 \
    -stim_times 1 stimuli/${subj}_${task}_events-cond1_global.txt GAM -stim_label 1 WA \
    -stim_times_IM 2 stimuli/${subj}_${task}_events-cond2_global.txt GAM -stim_label 2 WV \
    -stim_times 3 stimuli/${subj}_${task}_events-cond3_global.txt GAM -stim_label 3 PA \
    -stim_times 4 stimuli/${subj}_${task}_events-cond4_global.txt GAM -stim_label 4 PV \
    -jobs $njob \
    -x1D ${cprefix}_X.xmat.1D -xjpeg ${cprefix}_X.jpg -x1D_uncensored ${cprefix}_X.nocensor.xmat.1D \
    -x1D_stop
# PA
cprefix='con3_PA'
3dDeconvolve -nodata $ntp $tr \
    -censor ${subj}_${task}_${cenv}.1D \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r01.1D head_motion_run1 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r02.1D head_motion_run2 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r03.1D head_motion_run3 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r04.1D head_motion_run4 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r05.1D head_motion_run5 \
    -ortvec ${subj}_${task}_run-01_${ortv}_demean_all.1D nuisance_regressors_run1 \
    -ortvec ${subj}_${task}_run-02_${ortv}_demean_all.1D nuisance_regressors_run2 \
    -ortvec ${subj}_${task}_run-03_${ortv}_demean_all.1D nuisance_regressors_run3 \
    -ortvec ${subj}_${task}_run-04_${ortv}_demean_all.1D nuisance_regressors_run4 \
    -ortvec ${subj}_${task}_run-05_${ortv}_demean_all.1D nuisance_regressors_run5 \
    -polort 2 \
    -global_times \
    -num_stimts 4 \
    -stim_times 1 stimuli/${subj}_${task}_events-cond1_global.txt GAM -stim_label 1 WA \
    -stim_times 2 stimuli/${subj}_${task}_events-cond2_global.txt GAM -stim_label 2 WV \
    -stim_times_IM 3 stimuli/${subj}_${task}_events-cond3_global.txt GAM -stim_label 3 PA \
    -stim_times 4 stimuli/${subj}_${task}_events-cond4_global.txt GAM -stim_label 4 PV \
    -jobs $njob \
    -x1D ${cprefix}_X.xmat.1D -xjpeg ${cprefix}_X.jpg -x1D_uncensored ${cprefix}_X.nocensor.xmat.1D \
    -x1D_stop
# PV
cprefix='con4_PV'
3dDeconvolve -nodata $ntp $tr \
    -censor ${subj}_${task}_${cenv}.1D \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r01.1D head_motion_run1 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r02.1D head_motion_run2 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r03.1D head_motion_run3 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r04.1D head_motion_run4 \
    -ortvec ${subj}_${task}_${hmpv}_demean_all.r05.1D head_motion_run5 \
    -ortvec ${subj}_${task}_run-01_${ortv}_demean_all.1D nuisance_regressors_run1 \
    -ortvec ${subj}_${task}_run-02_${ortv}_demean_all.1D nuisance_regressors_run2 \
    -ortvec ${subj}_${task}_run-03_${ortv}_demean_all.1D nuisance_regressors_run3 \
    -ortvec ${subj}_${task}_run-04_${ortv}_demean_all.1D nuisance_regressors_run4 \
    -ortvec ${subj}_${task}_run-05_${ortv}_demean_all.1D nuisance_regressors_run5 \
    -polort 2 \
    -global_times \
    -num_stimts 4 \
    -stim_times 1 stimuli/${subj}_${task}_events-cond1_global.txt GAM -stim_label 1 WA \
    -stim_times 2 stimuli/${subj}_${task}_events-cond2_global.txt GAM -stim_label 2 WV \
    -stim_times 3 stimuli/${subj}_${task}_events-cond3_global.txt GAM -stim_label 3 PA \
    -stim_times_IM 4 stimuli/${subj}_${task}_events-cond4_global.txt GAM -stim_label 4 PV \
    -jobs $njob \
    -x1D ${cprefix}_X.xmat.1D -xjpeg ${cprefix}_X.jpg -x1D_uncensored ${cprefix}_X.nocensor.xmat.1D \
    -x1D_stop

# run 3dLSS to obtain trial-wise estimates
declare -a cons=("WA" "WV" "PA" "PV")
i=1
for icon in ${cons[@]};do
  echo -e "run LSS for condition $i $icon ......"
  cprefix=`printf "con%d_%s" $i $icon`
  3dLSS -matrix ${cprefix}_X.xmat.1D -input LSS.${subj}_${task}.all.scale+tlrc.HEAD -mask ${subj}_EPI_GM_mask4LSS+tlrc -save1D LSS_${cprefix}.1D -prefix LSS.stats.${subj}_${task}_${cprefix}
  let i+=1
done
