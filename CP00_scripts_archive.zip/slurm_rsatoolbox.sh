#!/bin/bash

#SBATCH -J RSA
#SBATCH -p skylake
#SBATCH --nodes=1
#SBATCH -A a187
#SBATCH -t 1-12
#SBATCH --cpus-per-task=32
#SBATCH --mem=180gb
#SBATCH -o ./skylake_log/ps05_RSA_%j.out
#SBATCH -e ./skylake_log/ps05_RSA_%j.err
#SBATCH --mail-type=ALL
#SBATCH --mail-user=ws1011001@gmail.com
#SBATCH --mail-type=BEGIN,END

# setup path
idir='/scratch/swang/simages'  # singularity images directory
mdir='/scratch/swang/agora/CP00'     # the project main directory
scripts='/CP00/scripts'        # scripts folder in Sy

# processing log
echo -e 'Running ps05_RSA_AudioVisAssos1word_ROIs_rsatoolbox.m with singularity'
singularity exec --bind $mdir:/CP00 $idir/nidebian-2.1 \
  matlab -nodisplay -nodesktop -r "try;cd('/CP00/scripts');run('ps05_RSA_AudioVisAssos1word_ROIs_rsatoolbox.m');catch ME;fprintf('RSA without success: %s\n', ME.message);end;exit"

#echo -e 'Running ps05_RSA_AudioVisAssos1word_Searchlight_rsatoolbox.m with singularity'
#singularity exec --bind $mdir:/CP00 $idir/nidebian-2.1 \
#  matlab -nodisplay -nodesktop -r "try;cd('/CP00/scripts');run('ps05_RSA_AudioVisAssos1word_Searchlight_rsatoolbox.m');catch ME;fprintf('RSA without success: %s\n', ME.message);end;exit"
