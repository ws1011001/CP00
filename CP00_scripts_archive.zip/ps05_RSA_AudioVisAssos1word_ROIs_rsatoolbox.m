%% ---------------------------
%% [script name] ps05_RSA_AudioVisAssos1word_ROIs_rsatoolbox.m 
%%
%% SCRIPT to do the representational similarity analysis for the AudioVisAssos1word task with the original design.The 
%% RSA will be performed on trial-wise estimates and focus on several ROIs.
%%
%% By Shuai Wang, [date]
%%
%% ---------------------------
%% Notes: Run this script on mesocentre using singularity and slurm.
%%        Dot '.' cannot be used as part of a m file name!!!
%%   
%%
%% ---------------------------

%% clean up
close all
clear
clc
%% ---------------------------

%% set environment (packages, functions, working path etc.)
% setup toolbox
addpath('/CP00/wang_tools/spm8');
addpath(genpath('/CP00/wang_tools/rsatoolbox'))
% data path and parameters
mdir='/CP00/AudioVisAsso/derivatives/';  % the Main folder
vdir=fullfile(mdir,'multivariate');  % multiVariate analyses folder
performRSA=1;  % set switch for RSA
%% ---------------------------

%% RSA settings
% subjects info
subj='sub-pilot2rc';  % REMINDER: replace '-' by '_'. MATLAB structures do not allow symbol '-'.
sessions={'words','pwords'};  
n=length(sessions);         % number of sessions
% setup RSA parameters
dataSettings.rootPath=fullfile(vdir,subj,'tvrRSA');  % Trial-wise Volume-based ROIs-only RSA
if ~exist(fullfile(dataSettings.rootPath,'temp_tvrRSA'),'dir')
    mkdir(fullfile(dataSettings.rootPath,'temp_tvrRSA'));
end
%dataSettings.analysisName='LanguageNetwork';
dataSettings.analysisName='mvpaROIs';
% ROIs
fid=fopen(fullfile(vdir,strcat(dataSettings.analysisName,'_ROIs_Labels.txt')));
ROIs=textscan(fid,'%s','delimiter','\n');
fclose(fid);
ROIs=ROIs{1};
nROI=length(ROIs);
dataSettings.maskNames=ROIs;
%% ---------------------------

%% perform ROI-based RSA
if performRSA
  for i=1:n
    tic;
    temp_dataSettings=dataSettings;
    temp_dataSettings.subjectNames=sessions(i);
    % prepare masks
%   temp_dataSettings.maskPath=fullfile(dataSettings.rootPath,sessions{i},'masks','[[maskName]].nii');
    temp_dataSettings.maskPath=fullfile(vdir,subj,'masks','[[maskName]].nii');
    % prepare fMRI data
    betaDir=fullfile(temp_dataSettings.rootPath,sessions{i},'betas_afni');
    betaFiles=dir(fullfile(betaDir,'*.nii'));
    betaNames=extractfield(betaFiles,'name');  % to be used as trial labels
    betas=cell2struct(betaNames(:),'identifier',2);
    betas=betas';  % to be used as the first argument in the function fMRIDataPreparation()
    temp_dataSettings.betaPath=fullfile(temp_dataSettings.rootPath,'[[subjectName]]','betas_afni','[[betaIdentifier]]');
    temp_dataSettings.conditionLabels=betaNames;
    temp_rsaVols=fMRIDataPreparation(betas,temp_dataSettings);
    temp_rsaMasks=fMRIMaskPreparation(temp_dataSettings);
    % calculate RDMs
    temp_rsaROIs=fMRIDataMasking(temp_rsaVols,temp_rsaMasks,betas,temp_dataSettings);
    temp_dataSettings.distance='Correlation';
    temp_dataSettings.RoIColor=[0 0 1];
    temp_RDMs=constructRDMs(temp_rsaROIs,betas,temp_dataSettings);
    % plot RDMs and MDS
    temp_dataSettings.displayFigures=false;
    temp_dataSettings.saveFiguresJpg=true;    
    figureRDMs(temp_RDMs,temp_dataSettings,struct('fileName',strcat(sessions{i},'_RDMs')));   
    filename=fullfile(temp_dataSettings.rootPath,'temp_tvrRSA',strcat(sessions{i},'.mat'));
    save(filename,'betas','temp*');
    clear beta* temp*
    toc;
    disp(strcat(sessions(i),' done...'));
  end
end
%% ---------------------------
