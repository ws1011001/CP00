#!/bin/bash
# by Shuai Wang

# setup path
mdir='/data/mesocentre/data/agora/CP00/AudioVisAsso'  # the project Main folder @totti
adir="$mdir/derivatives/afni"       # AFNI output folder

# processing parameters
subj='sub-pilot2rc'                 # subject ID (should be a list)
task='task-AudioVisAssos2words'            # task name
wdir="$adir/$subj/$task"          # the Working folder
rdir="$adir/$subj/individual_ROIs"                   # the individual ROIs folder
rfile="$rdir/RepetitionSuppression_ROIs_Labels.txt"  # ROIs list
readarray -t rois < $rfile                           # all ROIs
tdir="$wdir/${subj}_${task}_GLM.wPSC.wTENT.wNR50"  # TENT folder
fdir="$tdir/ROIana"

# refine individual ROIs with individual GM mask
for iroi in ${rois[@]};do
  if [ ! -f "$fdir/ROI_${iroi}_${subj}_${task}.IRF.all.1D" ];then
    1dcat $fdir/ROI_${iroi}_${subj}_${task}.*.IRF.1D > $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.1D
  fi
  # plot the FIR time course for this ROI
  1dRplot -input $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.1D \
    -save $fdir/ROI_${iroi}_${subj}_${task}.IRF.all.pdf \
    -save.size 4000 3000 \
    -TR 1.17 \
    -title "${iroi} - FIR time Course" \
    -xax.label 'Time (seconds)' \
    -yax.label 'Percent Signal Change' \
    -col.name catch DIDMa DIDMv DISMa DISMv SIDMa SIDMv SISMa SISMv \
    -col.color 1 2 3 4 5 2 3 4 5 \
    -col.line.type 3 2 2 2 2 1 1 1 1 \
    -col.plot.type b \
    -grid.show \
    -leg.show \
    -leg.position topleft \
    -one \
    -zeros  
done

