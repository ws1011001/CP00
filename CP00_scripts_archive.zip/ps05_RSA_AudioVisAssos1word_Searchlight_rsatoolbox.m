%% ---------------------------
%% [script name] ps05_RSA_AudioVisAssos1word_Searchlight_rsatoolbox.m 
%%
%% SCRIPT to do the representational similarity analysis for the AudioVisAssos1word task with the original design. The 
%% RSA will be performed on trial-wise estimates with searchlight method.
%%
%% By Shuai Wang, [date]
%%
%% ---------------------------
%% Notes: Run this script on mesocentre using singularity and slurm.
%%        Dot '.' cannot be used as part of a m file name!!!
%%   
%%
%% ---------------------------

%% clean up
close all
clear
clc
%% ---------------------------

%% set environment (packages, functions, working path etc.)
% setup toolbox
addpath('/CP00/wang_tools/spm8');
addpath(genpath('/CP00/wang_tools/rsatoolbox'))
% data path and parameters
mdir='/CP00/AudioVisAsso/derivatives/';  % the Main folder
vdir=fullfile(mdir,'multivariate');  % multiVariate analyses folder
performRSA=1;  % set switch for RSA
%% ---------------------------

%% RSA settings
% subjects info
subj='sub-pilot2rc';  % REMINDER: replace '-' by '_'. MATLAB structures do not allow symbol '-'.
sessions={'words','pwords'};  
n=length(sessions);         % number of sessions
% setup RSA parameters
dataSettings.rootPath=fullfile(vdir,subj,'tvsRSA');  % Trial-wise Volume-based Searchlight RSA
dataSettings.analysisName='Searchlight4mm_iLVOT';
dataSettings.searchlightRadius=4;           % searchlight kernel radius (mm)
dataSettings.voxelSize=[1.754 1.754 1.75];  % 57 voxels
if ~exist(fullfile(dataSettings.rootPath,'temp_tvsRSA'),'dir')
    mkdir(fullfile(dataSettings.rootPath,'temp_tvsRSA'));
end
% trial-wise RDM models
load(fullfile(vdir,subj,'Pilot2_RSA_models_words.mat'));  % load the trial-wise RDM models for words
twModels_words.AuditoryCodingAbstract=words_AuditoryCodingAbstract;
twModels_words.AuditoryCodingPLD=words_AuditoryCodingPLD;
twModels_words.VisualCodingAbstract=words_VisualCodingAbstract;
twModels_words.VisualCodingOLD=words_VisualCodingOLD;
twModels_words.HeteromodalAbstract=words_HeteromodalAbstract;
twModels_words.HeteromodalXLD=words_HeteromodalXLD;
twModels_words.MultimodalAthMean=words_MultimodalAthMean;
twModels_words.MultimodalGeoMean=words_MultimodalGeoMean;
twModels_words.OLD=words_OLD;
twModels_words.PLD=words_PLD;
rdmModels_words=constructModelRDMs(twModels_words,dataSettings);
RDMs_models{1}=rdmModels_words;
load(fullfile(vdir,subj,'Pilot2_RSA_models_pseudowords.mat'));  % load the trial-wise RDM models for pseudowords
twModels_pwords.AuditoryCodingAbstract=pwords_AuditoryCodingAbstract;
twModels_pwords.AuditoryCodingPLD=pwords_AuditoryCodingPLD;
twModels_pwords.VisualCodingAbstract=pwords_VisualCodingAbstract;
twModels_pwords.VisualCodingOLD=pwords_VisualCodingOLD;
twModels_pwords.HeteromodalAbstract=pwords_HeteromodalAbstract;
twModels_pwords.HeteromodalXLD=pwords_HeteromodalXLD;
twModels_pwords.MultimodalAthMean=pwords_MultimodalAthMean;
twModels_pwords.MultimodalGeoMean=pwords_MultimodalGeoMean;
twModels_pwords.OLD=pwords_OLD;
twModels_pwords.PLD=pwords_PLD;
rdmModels_pwords=constructModelRDMs(twModels_pwords,dataSettings);
RDMs_models{2}=rdmModels_pwords;
%% ---------------------------

%% perform searchlight RSA
if performRSA
  for i=1:n
    tic;
    temp_dataSettings=dataSettings;
    temp_dataSettings.subjectNames=sessions(i);
    % prepare fMRI data (GLM beta)
    betaDir=fullfile(temp_dataSettings.rootPath,sessions{i},'betas_afni');
    betaFiles=dir(fullfile(betaDir,'*.nii'));
    betaNames=extractfield(betaFiles,'name');  % to be used as conditionLabels
    betas=cell2struct(betaNames(:),'identifier',2);
    betas=betas';  % to be used as the first argument in the function fMRIDataPreparation()
    temp_dataSettings.betaPath=fullfile(temp_dataSettings.rootPath,'[[subjectName]]','betas_afni','[[betaIdentifier]]');
    temp_dataSettings.conditionLabels=betaNames;
    temp_rsaVols=fMRIDataPreparation(betas,temp_dataSettings);
    % prepare masks
%    temp_dataSettings.maskPath=fullfile(dataSettings.rootPath,sessions{i},'masks','[[maskName]].nii');
    temp_dataSettings.maskPath=fullfile(vdir,subj,'masks','[[maskName]].nii');
    temp_dataSettings.maskNames={'iLVOT'};
    temp_rsaMasks=fMRIMaskPreparation(temp_dataSettings);
    % save to the temporaary working folder
    filename=fullfile(temp_dataSettings.rootPath,'temp_tvsRSA',strcat(dataSettings.analysisName,'_',sessions{i},'.mat'));
    save(filename,'betas','temp*');
    clear beta* temp*
    toc;
    disp(strcat(sessions(i),' data preparation done...'));
  end

  % process one session at a time
  for j=1:n
    temp_subjName=sessions{j};
    fprintf(strcat(temp_subjName,' processing......\n'));
    filename=fullfile(dataSettings.rootPath,'temp_tvsRSA',strcat(dataSettings.analysisName,'_',temp_subjName,'.mat'));
    load(filename);
    fMRISingleSearchlight(temp_rsaVols,temp_rsaMasks,RDMs_models{i},betas,temp_dataSettings,0);  % 0: do not save voxel-wise RDMs
    fprintf(strcat(temp_subjName,' finished......\n'));
    clear betas temp*
  end
end
%% ---------------------------
